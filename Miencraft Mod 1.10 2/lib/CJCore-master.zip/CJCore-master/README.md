# CJCore
## About the mod
CJCore is a mod aimed at simplifying more complicated tasks. It works as an inbetween mod for APIs. It allows the users to easily use utility methods to allow energy integration etc. a whole lot easier.

## Can I use this mod in a mod pack?
Yes you can but please notify me so I can see where my mod is being used (you don't have to but it would be nice)

## Can I use the code for my own mod?
Of course! My mod is open source and means that anyone can use my code but please don't claim any code as your own :D

http://www.youtube.com/cjminecraft
