package cjminecraft.core.proxy;

import cjminecraft.core.energy.EnergyUnits;

/**
 * For all things server
 * @author CJMinecraft
 *
 */
public class ServerProxy extends CommonProxy {
	
	@Override
	public void preInit() {	
		super.preInit();
	}
	
	@Override
	public void init() {
		super.init();
	}
	
	@Override
	public void postInit() {
		super.postInit();
	}

}
