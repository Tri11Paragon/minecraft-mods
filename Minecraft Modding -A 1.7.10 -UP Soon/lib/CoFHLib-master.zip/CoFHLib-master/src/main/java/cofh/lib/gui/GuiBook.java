package cofh.lib.gui;

import net.minecraft.client.gui.GuiScreen;

public class GuiBook extends GuiScreen {

	protected int mouseX = 0;
	protected int mouseY = 0;

}
